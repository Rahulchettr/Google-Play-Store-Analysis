# Google Play Store Analytics Dashboard

A comprehensive interactive dashboard showcasing analytics from Google Play Store apps data.

## Features
- Category distribution analysis
- Rating analysis and distribution
- Free vs Paid apps comparison
- Top apps by reviews
- Content rating distribution
- App size analysis

## Technology Stack
- HTML5
- CSS3 with modern gradients and animations
- Plotly.js for interactive charts
- Netlify for hosting

## Deployment
This project is configured for easy deployment on Netlify.
