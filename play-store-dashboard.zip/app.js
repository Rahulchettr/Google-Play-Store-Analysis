// Initialize all charts when page loads
document.addEventListener('DOMContentLoaded', function() {
    createCategoryChart();
    createRatingChart();
    createPriceChart();
    createReviewsChart();
    createContentRatingChart();
    createSizeChart();
    
    // Make charts responsive
    window.addEventListener('resize', function() {
        Plotly.Plots.resize(document.getElementById('categoryChart'));
        Plotly.Plots.resize(document.getElementById('ratingChart'));
        Plotly.Plots.resize(document.getElementById('priceChart'));
        Plotly.Plots.resize(document.getElementById('reviewsChart'));
        Plotly.Plots.resize(document.getElementById('contentRatingChart'));
        Plotly.Plots.resize(document.getElementById('sizeChart'));
    });
});

function createCategoryChart() {
    var trace = {
        x: ['Family', 'Game', 'Tools', 'Business', 'Medical', 'Personalization', 'Communication', 'Sports', 'Lifestyle', 'Finance'],
        y: [1972, 1144, 843, 460, 463, 392, 387, 384, 382, 366],
        type: 'bar',
        marker: {
            color: ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#43e97b', '#38f9d7', '#fa709a', '#ffecd2', '#fcb69f']
        }
    };

    var layout = {
        title: 'Number of Apps by Category',
        xaxis: {title: 'Categories', tickangle: -45},
        yaxis: {title: 'Number of Apps'},
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {t: 50, r: 30, b: 80, l: 60}
    };

    Plotly.newPlot('categoryChart', [trace], layout);
}

function createRatingChart() {
    var trace = {
        x: [1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5],
        y: [500, 800, 1500, 3000, 4500, 6500, 8000, 5000, 3000],
        type: 'bar',
        marker: {
            color: 'linear-gradient(45deg, #667eea, #764ba2)'
        }
    };

    var layout = {
        title: 'App Rating Distribution',
        xaxis: {title: 'Rating (1-5 stars)'},
        yaxis: {title: 'Number of Apps'},
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {t: 50, r: 30, b: 60, l: 60}
    };

    Plotly.newPlot('ratingChart', [trace], layout);
}

function createPriceChart() {
    var data = [{
        values: [92, 8],
        labels: ['Free Apps', 'Paid Apps'],
        type: 'pie',
        marker: {
            colors: ['#667eea', '#764ba2']
        },
        hole: 0.4,
        textinfo: 'label+percent',
        hoverinfo: 'label+value+percent'
    }];

    var layout = {
        title: 'Free vs Paid Apps Distribution',
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        showlegend: false,
        margin: {t: 50, r: 30, b: 30, l: 30}
    };

    Plotly.newPlot('priceChart', data, layout);
}

function createReviewsChart() {
    var trace = {
        x: ['Facebook', 'WhatsApp', 'Instagram', 'Clash of Clans', 'Messenger', 'Subway Surfers', 'Candy Crush Saga', 'Twitter', 'Google Photos', 'Skype'],
        y: [78158306, 69119316, 66577313, 44891723, 38328354, 27722299, 22492464, 22109614, 21534993, 18608612],
        type: 'bar',
        marker: {
            color: 'linear-gradient(45deg, #ff6b6b, #ff8e8e)'
        }
    };

    var layout = {
        title: 'Top 10 Apps by Number of Reviews',
        xaxis: {title: 'App Name', tickangle: -45},
        yaxis: {title: 'Number of Reviews', type: 'log'},
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {t: 50, r: 30, b: 100, l: 80}
    };

    Plotly.newPlot('reviewsChart', [trace], layout);
}

function createContentRatingChart() {
    var data = [{
        values: [45, 25, 15, 10, 5],
        labels: ['Everyone', 'Teen', 'Everyone 10+', 'Mature 17+', 'Adults only 18+'],
        type: 'pie',
        marker: {
            colors: ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe']
        }
    }];

    var layout = {
        title: 'Content Rating Distribution',
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {t: 50, r: 30, b: 30, l: 30}
    };

    Plotly.newPlot('contentRatingChart', data, layout);
}

function createSizeChart() {
    var trace = {
        x: ['0-10MB', '10-50MB', '50-100MB', '100-500MB', '500MB+'],
        y: [4000, 3500, 1500, 800, 200],
        type: 'bar',
        marker: {
            color: 'linear-gradient(45deg, #43e97b, #38f9d7)'
        }
    };

    var layout = {
        title: 'App Size Distribution',
        xaxis: {title: 'App Size'},
        yaxis: {title: 'Number of Apps'},
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        margin: {t: 50, r: 30, b: 60, l: 60}
    };

    Plotly.newPlot('sizeChart', [trace], layout);
}
